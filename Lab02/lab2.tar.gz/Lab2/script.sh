#!/bin/bash
current_date=$(date)
echo "The date is: $current_date"

current_time=$(date +%s)
echo "The time is: $current_time"

let double_time=current_time*2
echo "The current time is: $current_time"
echo "The time in doyble is: $double_time"

for i in {1..20}; do
echo "Number: $i"
done
